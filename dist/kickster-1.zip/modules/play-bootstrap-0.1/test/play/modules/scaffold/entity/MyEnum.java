package play.modules.scaffold.entity;

public enum MyEnum {
	ONE, TWO, THREE;
}
