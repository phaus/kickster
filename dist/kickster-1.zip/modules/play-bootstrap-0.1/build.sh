#!/bin/bash
ant dist -Dplay.path=$PLAY_HOME