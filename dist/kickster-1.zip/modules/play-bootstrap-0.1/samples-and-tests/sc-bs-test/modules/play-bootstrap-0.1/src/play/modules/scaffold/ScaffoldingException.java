package play.modules.scaffold;

public class ScaffoldingException extends RuntimeException {
    private static final long serialVersionUID = 664301427097621450L;

    public ScaffoldingException(String message) {
        super(message);
    }
}
