play-bootstrap
================

A Bootstrap Scaffold Module for the Play Framework. Based on the original Scaffold Module.


## HowTo & Test

> ./build.sh

Then

> cd samples-and-tests/sc-bs-test

after that

> play deps --sync

and

> play bs:gen --with-layout --overwrite

or use the script

> ./generate.sh


## Demo of a generated app

http://radiant-earth-9626.herokuapp.com/


## Links

* original Scaffold Module

https://github.com/lmcalpin/Play--Scaffold

* Bootstrap Homepage

http://twitter.github.com/bootstrap