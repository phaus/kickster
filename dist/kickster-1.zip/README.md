![Kickster Logo](https://github.com/phaus/kickster/raw/master/public/img/logo-small.png "Kickster Logo")

kickster
========

a kicker game statistic tool

## Setup

* Download Play 1.x from http://download.playframework.org/releases/play-1.2.5.zip 
* Extract to a reasonable directory (say _/opt/play_).
* Make play command accessible within your path - e.g. adding to .profile or just

        export PATH=$PATH:/opt/play/play

* run the app with 

        play run

or

    play start/stop


## Demo

http://strong-frost-6132.herokuapp.com/